package Avatar;

public enum Layer 
{
    HEAD_LAYER, FACE_LAYER, HAIR_LAYER, ITEM_LAYER;
};
