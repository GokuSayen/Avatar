package Avatar;

import java.awt.*;

public class Sprite 
{
	private static final String path = "images/";
	private String name;
	private String description;
	private Point position;
	
	// Reference on an enum
	private Layer layer;
	
	//constructor of the sprite
	public Sprite(String name, String description, Point position, Layer layer)
	{
		this.name = name;
		this.description = description;
		this.position = position;
		this.layer = layer;
	}
	
	// method which returns the sprite's name
	public String getName()
	{
		return name;
	}
	
	// method which returns the sprite's path
	public String getFullPath()
	{
		return path + name;
	}
	
	// method which returns the sprite's description
	public String getDescription()
	{
		return description;
	}
	
	// method which returns the sprite's position considering x
	public int getX()
	{
		return position.x;
	}

	// method which returns the sprite's position considering y
	public int getY()
	{
		return position.y;
	}
	
	// method which returns the Layer'value
	public int getLayerValue()
	{
		// Instance's index. Here 0 as HEAD_LAYER was the first declared.
		int valueLayer = layer.ordinal(); 
		return valueLayer;
	}

	// method which returns the Layer'name
	public String getLayerName()
	{
		// Instance's text value. Here "HEAD_LAYER"
		String nameLayer = layer.toString(); 
		return nameLayer;
	}
}
