package Avatar;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.util.ArrayList;

public class GUI implements  ActionListener, ChangeListener
{
	JFrame window; 
	
	JLayeredPane layeredPane;
	//ArrayList<JLayeredPane> list1 = new ArrayList<JLayeredPane>();
	
	//Allcating a new sprite 
	//tableau des Sprites pour les yeux eyes
	private Sprite eyes_angry;
	private Sprite eyes_calm;
	private Sprite eyes_disoriented;
	private final Sprite[] eyesSprite = 
	{			
		eyes_angry = new Sprite("eyes_angry.png", "Faches", new Point(365, 340), Layer.FACE_LAYER),
		eyes_calm = new Sprite("eyes_calm.png", "Calmes", new Point(375, 350), Layer.FACE_LAYER),
		eyes_disoriented = new Sprite("eyes_disoriented.png", "Desorientes", new Point(370, 350), Layer.FACE_LAYER),
	};

	Sprite eyesChoice = null; // on va stocker dans cet objet la forme des yeux choisis par l'utilisateur
	
	//tableau des Sprites pour la t�te Heads
	private Sprite head_1_mask;
	private Sprite head_2_mask;
	private Sprite head_3_mask;
	private final Sprite[] headSprite = 
	{
		head_1_mask = new Sprite("head_1_mask.png", "Classique", new Point(180, 200), Layer.HEAD_LAYER),
		head_2_mask = new Sprite("head_2_mask.png", "Rond", new Point(180, 200), Layer.HEAD_LAYER),
		head_3_mask = new Sprite("head_3_mask.png", "Pointu", new Point(180, 200), Layer.HEAD_LAYER),
	};
	
	Sprite headChoice = null;// on va stocker dans cet objet la forme t�te choisie par l'utilisateur
	

	//tableau des Sprites pour le nez noses
	private Sprite nose_round;
	private Sprite nose_greek;
	private Sprite nose_clown;
	private final Sprite[] nosesSprite = 
	{
		nose_round = new Sprite("nose_round.png", "Nez rond", new Point(380, 410), Layer.FACE_LAYER),
		nose_greek = new Sprite("nose_greek.png", "Nez grec", new Point(380, 410), Layer.FACE_LAYER),
		nose_clown = new Sprite("nose_clown.png", "Nez clow", new Point(385, 410), Layer.FACE_LAYER),
	};

	Sprite noseChoice = null;// on va stocker dans cet objet la forme du nez choisi par l'utilisateur
	
	//tableau des Sprites pour  la bouche mouths
	private Sprite mouth_sad;
	private Sprite mouth_happy;
	private Sprite mouth_smiling;
	private final Sprite[] mouthSprite = 
	{
		mouth_sad = new Sprite("mouth_sad.png", "Triste", new Point(330, 500), Layer.FACE_LAYER),
		mouth_smiling = new Sprite("mouth_smiling.png", "Souriant", new Point(280, 480), Layer.FACE_LAYER),
		mouth_happy = new Sprite("mouth_happy.png", "Content", new Point(260, 460), Layer.FACE_LAYER),
	};

	Sprite mouthChoice = null;
	
	//tableau des Sprites pour les cheveux hairs des hommes
	private Sprite hair_h_1;
	private Sprite hair_h_2;
	private Sprite hair_h_3;
	private Sprite hair_h_4;
	/*private Sprite deleteMen_hair;*/
	private final Sprite[] menhairsSprite = 
	{
		hair_h_1 = new Sprite("hair_h_1.png", "", new Point(160, 150), Layer.HAIR_LAYER),
		hair_h_2 = new Sprite("hair_h_2.png", "", new Point(200, 150), Layer.HAIR_LAYER),
		hair_h_3 =  new Sprite("hair_h_3.png", "", new Point(180, 180), Layer.HAIR_LAYER),
		hair_h_4 = new Sprite("hair_h_4.png", "", new Point(60, 155), Layer.HAIR_LAYER),
		hair_h_1 = new Sprite("hair_h_1.png", "", new Point(160, 150), Layer.HAIR_LAYER),
		hair_h_2 = new Sprite("hair_h_2.png", "", new Point(200, 150), Layer.HAIR_LAYER),
		hair_h_3 =  new Sprite("hair_h_3.png", "", new Point(180, 180), Layer.HAIR_LAYER),
		hair_h_4 = new Sprite("hair_h_4.png", "", new Point(60, 155), Layer.HAIR_LAYER),
		/* Sprite permettant d'effacer(masquer) les autres sprites cheveux avant de mettre des nouveaux
		deleteMen_hair = new Sprite("efface.png", "", new Point(30, 130), Layer.HAIR_LAYER),*/
	};
	
	//tableau des Sprites pour les cheveux hairs des femmes
	private Sprite hair_f_1;
	private Sprite hair_f_2;
	private Sprite hair_f_3;
	private Sprite hair_f_4;
	/*private Sprite deleteWomen_hair;*/
	private final Sprite[] womenhairsSprite = 
	{
		hair_f_1 = new Sprite("hair_f_1.png", "", new Point(30, 130), Layer.HAIR_LAYER),
		hair_f_2 = new Sprite("hair_f_2.png", "", new Point(160, 180), Layer.HAIR_LAYER),
		hair_f_3 = new Sprite("hair_f_3.png", "", new Point(140, 180), Layer.HAIR_LAYER),
		hair_f_4 = new Sprite("hair_f_4.png", "", new Point(60, 110), Layer.HAIR_LAYER),
		/* Sprite permettant d'effacer(masquer) les autres sprites cheveux avant de mettre des nouveaux
		deleteWomen_hair = new Sprite("efface.png", "", new Point(30, 130), Layer.HAIR_LAYER),*/
	};
	
	//Sprite permettant d'effacer(masquer) les autres sprites cheveux avant de mettre des nouveaux
	private Sprite efface = new Sprite("efface.png", "", new Point(30, 110), Layer.HAIR_LAYER);


	//tableau des Sprites pour les accessoires (items) : lunettes, ruban...
	private Sprite item_blush;
	private Sprite item_glasses;
	private Sprite item_ruban;
	private final Sprite[] itemsSprite = 
	{
			item_blush = new Sprite("item_blush.png", "Timide", new Point(230, 380), Layer.FACE_LAYER),
			item_glasses = new Sprite("item_glasses.png", "Lunettes", new Point(265, 320), Layer.ITEM_LAYER),
			item_ruban = new Sprite("item_ruban.png", "Ruban", new Point(180, 200), Layer.ITEM_LAYER),
	};
	// variable qui contient le texte assign� aux JCheckBox � leur cr�ation
	JCheckBox blushCheckBox;
	JCheckBox glassesCheckBox;
	JCheckBox rubanCheckBox;
	int etat = 0;
	int etat1 = 0;
	int etat2 = 0;
	Sprite itemChosen;
	
	//tableau des couleurs
	private Color Color0;
	private Color Color1;
	private Color Color2;
	private Color Color3;
	private Color Color4;
	private Color Color5;
	private Color Color6;
	private Color Color7;
	private final Color [] headColors = 
	{ 
		Color0 = new Color(21, 114, 200),
		Color1 = new Color(205, 222, 135),
		Color2 = new Color(255, 230, 128),
		Color3 = new Color(222, 135, 135), 
		Color4 = new Color(232, 204, 186), 
		Color5 = new Color(222, 170, 135), 
		Color6 = new Color(200, 113, 55), 
		Color7 = new Color(85, 33, 0)
	};
	
	Color headColor;// on va stocker dans cet objet la couleur choisie par l'utilisateur
	
	//referent for the control pane
	JPanel controlPanel;
	
	//referent for the panel containing the JButtons for the Color
	JPanel color;
	JButton bouton;

	//referent for the panel containing the JSlider for the hairs
	JPanel hairSlider;
	JSlider coiffure;
	int sizeJSlider = 4;
	int hairValueMen; // valeur s�lectionner su la jauge
	int hairValueWomen; // valeur s�lectionner su la jauge

	// referent for the panel containing the JRadioButton for the choice of the sex 
	JPanel sexe;
	String sexeSelected;
	JRadioButton men;
	JRadioButton women;
	ButtonGroup group;

	// referent for the panel containing the JComboBox for the choice of the head, the eyes, the nose and the mouth 
	JPanel form;
	JComboBox eyesCombo;
	JComboBox headCombo;
	JComboBox noseCombo;
	JComboBox mouthCombo;
	
	// referent for the panel containing the JCheckBox for the choice of the items : glasses, ruban and blush   
	JPanel itemsCheckBox;
	JCheckBox caseCheckBox;
	
	// referent for the panel containing the JButton to validate the choice of the user   
	JPanel validate;
	JButton update;
			
	// constructor
	public GUI()
	{
		
			//Allocating a new JFrame to be the main window
			window = new JFrame("GENERATEUR D'AVATAR"); 
	
			//for put the Sprite in the background or the foreground
			layeredPane = new JLayeredPane();
			
			//Layout principal
			window.setLayout(new BorderLayout());
			
			//Panneau de control 
			controlPanel = new JPanel(new GridLayout(6,1));
			controlPanel.setPreferredSize(new Dimension(350, 20));
			
			//Fonction qui cr�e le panneau contenant les boutons pour la couleur
			buttonColor();
			
			//Fonction qui cr�e le panneau contenant les boutons pour le choix du sexe de notre Image
			sexChoice();

			//method which changes the JSlider Panel value considering the type of sex chosen
			checkGenre();

			//Fonction qui cr�e le panneau contenant la jauge pour le choix des coiffures 
			hairsSlider();
			
			//Fonction qui cr�e le panneau contenant le menu combo pour le choix de la forme du nez, face ect... 
			form();

			//Fonction qui cr�e le panneau contenant le menu checkBox pour le choix des accesoires : lunettes etc...
			items();

			//Fonction qui cr�e le panneau contenant le bouton de validation
			validateChoice();
	
			// ajout du panel de control � la fen�tre 
		    window.add(controlPanel, BorderLayout.WEST);
		
		    // efface l'ancien sprite et met � jour le nouveau en fonction du choix de l'user
			selectImage();
		    
		    // ajout du layeredPane dans la fen�tre
		    window.add(layeredPane, BorderLayout.CENTER);
		    
			// Default configuration of the window
			window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			window.setMinimumSize(new Dimension(1280,770));
			
			//Resizing the window considering the new items 
			window.pack();
			
			// showing the window
			window.setVisible(true);
		}
	
		/*=======================================Fonction qui cr�e le panneau contenant les boutons pour le choix des couleurs==========*/ 
	
	
		//Fonction qui cr�e le panneau contenant les boutons pour la couleur
		public void buttonColor()
		{
			//Panneau contenant les boutons pour la couleur
			color = new JPanel(new GridLayout(1,8));
			//Creation des boutons et ajout des boutons couleurs dans le panneau couleur
			for(int i=0; i<headColors.length;i++)
			{
				// on cr�e un indice sur chaque bouton couleur. Indice compos� du texte Color + le num�ro de la position de la couleur dans le tableau
				String indice = "Color" + String.valueOf(i);
				//System.out.println(indice);
				//cr�e le bouton
				bouton = new JButton();
				// if user click on one of the color butons
				bouton.addActionListener(this);
				bouton.setActionCommand(indice);// indice = "Color0" ou "Color1" ou "Color2"....
				// mise de la couleur sur le bouton
				bouton.setOpaque(true); // Not transparent 
				bouton.setBackground(headColors[i]);
				//ajout du bouton dans le panel color
				color.add(bouton);
			}
			//Ajout du panneau color dans le Panneau de control : controlPanel
			controlPanel.add(color);
		}
		
		/*=======================================Fonction qui cr�e le panneau contenant les boutons pour le choix du sexe de notre Image==========*/ 
		public void sexChoice()
		{
			//Panneau contenant les boutons pour le choix du sexe de notre Image
			sexe = new JPanel(new GridLayout(1,8));
			//Creation des boutons et ajout des boutons radio dans le panneau sexe
			men = new JRadioButton("Men");
			women = new JRadioButton("Women");
			// action selon le choix de l'user : on appel la fonction actionPerformed de l'interface ActionListener
			men.addActionListener(this); 
			men.setActionCommand("men");
			women.addActionListener(this); 
			women.setActionCommand("women");			
			// creation d'un group qui va contenir les boutons de choix afin qu'un seul soit selectionnable � la fois
			group = new ButtonGroup();
			group.add(men);
			group.add(women);
			// ajout des boutons dans le panel "sexe"
			sexe.add(men);
			sexe.add(women);
			// ajout du panneau genre dans le Panneau de control : controlPanel
			controlPanel.add(sexe);
		}
		
		
		/*=======================================Fonction qui cr�e le panneau contenant la jauge pour le choix des coiffures==========*/ 
		public void hairsSlider()
		{

			//Panneau contenant la jauge pour le choix des coiffures 
			hairSlider = new JPanel(new FlowLayout(FlowLayout.LEFT));
			//ajout d'�l�ments dans le panel hair
			coiffure = new JSlider(JSlider.HORIZONTAL, 1, sizeJSlider, 1);
			// definition de la graduation
	        coiffure.setMinorTickSpacing(1);
	        coiffure.setMajorTickSpacing(sizeJSlider);
	        coiffure.setPaintTicks(true);
	        coiffure.setPaintLabels(true);
	        coiffure.setLabelTable(coiffure.createStandardLabels(1));
			// if user change the value of the JSlider
	        coiffure.addChangeListener(this);
	        //ajout dans le panel
	        hairSlider.add(new JLabel("Coiffure"));
	        hairSlider.add(coiffure);
			// ajout du panneau hair dans le Panneau de control : controlPanel
			controlPanel.add(hairSlider);
			
			//coiffure.removeAll();
			//coiffure.updateUI();
		}
		
		/*=======================================Fonction qui cr�e le panneau contenant le menu combo pour le choix de la forme du nez, face ect...==========*/ 
		public void form()
		{
			//panneau contenant le menu combo pour le choix de la forme du nez, face ect... 
			form = new JPanel(new GridLayout(4,1));
			//create a JComboBox for the head
			headCombo = new JComboBox();
			headCombo.setPreferredSize(new Dimension(100, 20));
			// add form of the head in the JComboBox 
			String nameHeadSprite = null;
			for(int i=0; i<headSprite.length;i++)
			{
				// to take the name of the sprite without ".png"
				if(headSprite[i].getName() != null)
				{
					// we pick up the name of the head in the head table
					nameHeadSprite = headSprite[i].getName().substring(0,headSprite[i].getName().indexOf('.'));
				}
				else
				{
					
				}
				//System.out.println(nameHeadSprite);
				headCombo.addItem(nameHeadSprite);
				headCombo.addActionListener(this);
				headCombo.setActionCommand("headCombo_");
			}
			
			//create a JComboBox for the eyes
			eyesCombo = new JComboBox();
			eyesCombo.setPreferredSize(new Dimension(100, 20));
			// add form of the eyes in the JComboBox 
			String nameEyesSprite = null;
			for(int i=0; i<eyesSprite.length;i++)
			{
				// to take the name of the sprite without ".png"
				if(eyesSprite[i].getName() != null)
				{
					// we pick up the name of the eyes in the eyes table
					nameEyesSprite = eyesSprite[i].getName().substring(0,eyesSprite[i].getName().indexOf('.'));
				}
				else
				{
					
				}
				//System.out.println(nameHeadSprite);
				eyesCombo.addItem(nameEyesSprite);
			}
			
			//create a JComboBox for the noses
			noseCombo = new JComboBox();
			noseCombo.setPreferredSize(new Dimension(100, 20));
			// add form of the noses in the JComboBox 
			String nameNosesSprite = null;
			for(int i=0; i<nosesSprite.length;i++)
			{
				// to take the name of the sprite without ".png"
				if(nosesSprite[i].getName() != null)
				{
					// we pick up the name of the noses in the noses table
					nameNosesSprite = nosesSprite[i].getName().substring(0,nosesSprite[i].getName().indexOf('.'));
				}
				else
				{
					
				}
				//System.out.println(nameHeadSprite);
				noseCombo.addItem(nameNosesSprite);
			}
	
			//create a JComboBox for the mouth
			mouthCombo = new JComboBox();
			mouthCombo.setPreferredSize(new Dimension(100, 20));
			// add form of the mouth in the JComboBox 
			String nameMouthSprite = null;
			for(int i=0; i<mouthSprite.length;i++)
			{
				// to take the name of the sprite without ".png"
				if(eyesSprite[i].getName() != null)
				{
					// we pick up the name of the noses in the noses table
					nameMouthSprite = mouthSprite[i].getName().substring(0,mouthSprite[i].getName().indexOf('.'));
				}
				else
				{
					
				}
				//System.out.println(nameMouthSprite);
				mouthCombo.addItem(nameMouthSprite);
			}
		    // ajout des champs de s�lection dans le panel form
			form.add(headCombo);
			form.add(eyesCombo);
			form.add(noseCombo);
			form.add(mouthCombo);
			// ajout du panneau form dans le Panneau de control : controlPanel
			controlPanel.add(form);

		}
		
		/*=======================================Fonction qui cr�e le panneau contenant le menu checkBox pour le choix des accesoires : lunettes etc...==========*/ 
		public void items()
		{
			//panneau contenant le menu checkBox pour le choix des accesoires : lunettes etc...
			itemsCheckBox = new JPanel(new GridLayout(3,1));
			// add form of the head in the JComboBox 
			
			// cr�ation des accessoires
			// joues rouge
			blushCheckBox = new JCheckBox("item_blush");
			blushCheckBox.addChangeListener(this);
			itemsCheckBox.add(blushCheckBox);
			
			// lunettes
			glassesCheckBox = new JCheckBox("item_glasses");
			glassesCheckBox.addChangeListener(this);
			itemsCheckBox.add(glassesCheckBox);
			
			// ruban 
			rubanCheckBox = new JCheckBox("item_ruban");
			rubanCheckBox.addChangeListener(this);
			itemsCheckBox.add(rubanCheckBox);
						
			// ajout du panneau form dans le Panneau de control : controlPanel
			controlPanel.add(itemsCheckBox);
		}
		
		/*=======================================Fonction qui cr�e le panneau contenant le bouton de validation==========================*/ 
		public void validateChoice()
		{
			//panneau contenant le bouton de validation
			validate = new JPanel(new BorderLayout());
			//ajout du bouton dans le panel validate
			update = new JButton("Update Avatar");
			update.addActionListener(this);
			update.setActionCommand("Update Avatar");
			update.setOpaque(true); // Not transparent 
			update.setBackground(Color.cyan);
			validate.add(update);
			// ajout du panneau form dans le Panneau de control : controlPanel
			controlPanel.add(validate, BorderLayout.CENTER);
		}
	
		/*==================== method adding the new sprite with colour ==================================================================*/
		/**
		 * Add the sprite s to the layeredPane object
		 * @param s the Sprite to add
		 * @param background the color of the background. If null, the background is transparent.
		 */
		private void addSprite(Sprite sprite, Color backgroundColor)
		{
				
				// Load the image from the disk
				ImageIcon tmpImg = new ImageIcon(sprite.getFullPath());
				// Create a component with the icon
				JLabel tmpLabel = new JLabel(tmpImg);
				// Set the position and the size of the component 
				tmpLabel.setBounds(sprite.getX(), sprite.getY(),
			    tmpImg.getIconWidth(), tmpImg.getIconHeight());
		        
			    //If a background color is defined
				if (backgroundColor != null) 
				{
				 tmpLabel.setOpaque(true); // Not transparent 
				 tmpLabel.setBackground(backgroundColor); // Set the background color
				}
				
			    /* on ajoute les sprites pass�s en param�tre dans le JLayeredPane. 
			     * Si le sprite est dans le tableau des t�tes, on le met en arri�re
			     * plan pour qu'il ne soit pas sur les autres Sprites
			     */
				// recuperation du nom du sprite pass� en param�tre, sprite.getName().indexOf('.') : retourne un int qui est le range du point
				String nameSpriteParametre = sprite.getName().substring(0,sprite.getName().indexOf('.'));
				int test = 0;
				for(int i=0; i<headSprite.length;i++)
				{
					//recuperation du nom du sprite dans le tableau des headSprite
					String nameSpriteTableau = headSprite[i].getName().substring(0,headSprite[i].getName().indexOf('.'));
					boolean egal = nameSpriteParametre.equals(nameSpriteTableau);
					// si c'est un Sprite t�te
					if(egal)
					{
						//System.out.println("Yo");
						test = 1;
					}
				}
				// pour que la t�te soit en arri�re plan
				if(test == 1)
				{
					layeredPane.add(tmpLabel, JLayeredPane.DEFAULT_LAYER);
				}
				
				/* on ajoute les sprites pass�s en param�tre dans le JLayeredPane. 
			     * Si le sprite est dans le tableau des accessoires, on le met en avant
			     * plan pour qu'il ne soit pas en dessous des autres Sprites
			     */
				// recuperation du nom du sprite pass� en param�tre
				int test1 = 0;
				for(int i=0; i<itemsSprite.length;i++)
				{
					//recuperation du nom du sprite dans le tableau des headSprite
					String nameSpriteTableau = itemsSprite[i].getName().substring(0,itemsSprite[i].getName().indexOf('.'));
					boolean egal = nameSpriteParametre.equals(nameSpriteTableau);
					// si c'est un Sprite t�te
					if(egal)
					{
						//System.out.println("Yo");
						test1 = 1;
					}
				}
				// pour que l'accessoire soit en avant plan
				if(test1 == 1)
				{
					layeredPane.add(tmpLabel, JLayeredPane.MODAL_LAYER);
				}
				
				if(test != 1 && test1 != 1)
				{
					layeredPane.add(tmpLabel, JLayeredPane.PALETTE_LAYER);
				}
				
				// on reinitialise nos variables de test pour le prochain cycle
				test = 0; test1 = 0;
		}
		
		/*==================== method adding the new sprite without color ===================================================================*/
		/*
		 * Wrapping of the addSprite(Sprite,Color) function with no color.
		 * @param s the Sprite to add
		 * Cette fonction permet d'appeller la fonction 
		 * private void addSprite(Sprite sprite, Color backgroundColor)
		 * si l'utilisateur � oublier seulement mis le sprite en param�tre
		 */
		private void addSprite(Sprite sprite) 
		{ 
			addSprite(sprite, null);
		}
	
		/*==================== method belonging to the interface ActionListener============================================================*/
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			// TODO Auto-generated method stub
			// on r�cup�re la couleur du bouton appuy�
			for(int i=0; i<headColors.length;i++)
			{
				// on cr�e un indice sur chaque bouton couleur compos� du texte Color + le num�ro de la position de la couleur dans le tableau
				String indice = "Color" + String.valueOf(i);
				//System.out.println(indice);
				if(e.getActionCommand().equals(indice)) // indice = "Color0" ou "Color1" ou "Color2".....
				{
					/* la couleur de la t�te est celle du bouton appuy� dont les param�tres sont
					Color( headColors[i].getRed(),headColors[i].getGreen(),headColors[i].getBlue() )= Color(21, 114, 200)*/
					headColor = new Color (headColors[i].getRed(),headColors[i].getGreen(),headColors[i].getBlue()); 
					//layeredPane.removeAll();
					selectImage();
				}
			}
			
			//if we click on JRadioButton for choose the sex 
			if(e.getActionCommand().equals("men"))
			{
				//method which changes the JSlider Panel value considering the type of sex chosen
				//System.out.println("I'm a boy");
				sexeSelected = "men";
				// on met la valeur de la posisition du curseur de la jauge des cheveux � 0
				hairValueMen = 1;
				// set the maximum value of the hairSlider considering the type of sex
				checkGenre();
			}
			
			if(e.getActionCommand().equals("women"))
			{
				//System.out.println("I'm a girl");
				sexeSelected = "women";
				// on met la valeur de la posisition du curseur de la jauge des cheveux � 0
				hairValueWomen = 1;
				// set the maximum value of the hairSlider considering the type of sex
				checkGenre();
			}
			
			// we get the choice of the head in the Head JComboBox
			if(e.getActionCommand().equals("headCombo_"))
			{
				// print the choice of the user in the head JCombobox
				//System.out.println(headCombo.getSelectedItem().toString());				
			}
			
			//if user clicks on the buton "update" to validate his choices 
			if(e.getActionCommand().equals("Update Avatar")) 
			{
				selectImage();
			}
		}
		
	
		/*=============================== method belonging to the interface ChangeListener==================*/
		@Override
		public void stateChanged(ChangeEvent ev)
		{
			// TODO Auto-generated method stub
			// if user change the value of the JSlider
			
			if(ev.getSource() == coiffure)
			{
				if(sexeSelected == "men")
				{
					//r�cup�re la valeur de la jauge de coiffure
					hairValueMen = coiffure.getValue();
					System.out.println("hairValueMen value " + hairValueMen);
					//selectImage();			
				}
				
				if(sexeSelected == "women")
				{
					//r�cup�re la valeur de la jauge de coiffure
					hairValueWomen = coiffure.getValue();
					System.out.println("hairValueWomen value " + hairValueWomen);
					//selectImage();			
				}
			}
			
			// test pour savoir quel accessoire doit �tre ajouter
			// joue rouge
			if(blushCheckBox.isSelected()){etat = 1;}else{etat = 0;}
			//lunette
			if(glassesCheckBox.isSelected()){etat1 = 1;}else{etat1 = 0;}
			//ruban
			if(rubanCheckBox.isSelected()){etat2 = 1;}else{etat2 = 0;}
			
		}
		
		/*============================= method to update the avatar considering the choices of the user ==================================*/
		public void selectImage()
		{
			//remove all the sprites on the GUI interface
			layeredPane.removeAll();
			
			/*on r�cup�re sous forme de string le choix fait dans le menu combo par l'utilisateur. Comme la fonction addSprite attend un objet 
			pas un string, on cherche dans un des tableaus des objets celui correpondant � l'objet consid�r�(soit headSprite, eyesSprite, ou mouthSprite etc.. ) celle qui correspond 
			� ce string.******/ 
			String choice = null;

			/*add to the LayeredPane the head selected by the user*/
			choice = headCombo.getSelectedItem().toString();
			for(int i=0; i<headSprite.length;i++)
			{
				/* we search in the head table the item which correponds to the string saved in the variable choice*/
				if( choice.equals(headSprite[i].getName().substring(0,headSprite[i].getName().indexOf('.'))) )
				{
					headChoice = new 	Sprite(headSprite[i].getName(),
							headSprite[i].getDescription(), 
							new Point( headSprite[i].getX(), headSprite[i].getY() ), 
							Layer.HEAD_LAYER );
					addSprite(headChoice,headColor);
				}
			}
			
			/*add to the LayeredPane the eyes selected by the user*/
			choice = eyesCombo.getSelectedItem().toString();
			for(int i=0; i<eyesSprite.length;i++)
			{
				/* we search in the eyes table the item which correponds to the string saved in the variable choice*/
				if( choice.equals(eyesSprite[i].getName().substring(0,eyesSprite[i].getName().indexOf('.'))) )
				{
					eyesChoice = new 	Sprite(eyesSprite[i].getName(),
							headSprite[i].getDescription(), 
							new Point( eyesSprite[i].getX(), eyesSprite[i].getY() ), 
							Layer.HEAD_LAYER );
					addSprite(eyesChoice,null);
				}
			}
			
			/*add to the LayeredPane the nose selected by the user*/
			choice = noseCombo.getSelectedItem().toString();
			for(int i=0; i<nosesSprite.length;i++)
			{
				/* we search in the noses table the item which correponds to the string saved in the variable choice*/
				if( choice.equals(nosesSprite[i].getName().substring(0,nosesSprite[i].getName().indexOf('.'))) )
				{
					noseChoice = new 	Sprite(nosesSprite[i].getName(),
							headSprite[i].getDescription(), 
							new Point( nosesSprite[i].getX(), nosesSprite[i].getY() ), 
							Layer.HEAD_LAYER );
					addSprite(noseChoice,null);
				}
			}	
			
			/*add to the LayeredPane the mouth selected by the user*/
			choice = mouthCombo.getSelectedItem().toString();
			for(int i=0; i<mouthSprite.length;i++)
			{
				/* we search in the mouth table the item which correponds to the string saved in the variable choice*/
				if( choice.equals(mouthSprite[i].getName().substring(0,mouthSprite[i].getName().indexOf('.'))) )
				{
					mouthChoice = new 	Sprite(mouthSprite[i].getName(),
							mouthSprite[i].getDescription(), 
							new Point( mouthSprite[i].getX(), mouthSprite[i].getY() ), 
							Layer.HEAD_LAYER );
					addSprite(mouthChoice,null);
				}
			}			
			
			/*======================== choix des cheveux =========================================================*/
			if(sexeSelected == "men")
			{		
				System.out.println("\nsexeSelected " + sexeSelected);
				addSprite(efface, null);				
				addSprite(menhairsSprite[hairValueMen-1], null);
			}
			
			if(sexeSelected == "women")
			{
				System.out.println("\nsexeSelected " + sexeSelected);
				addSprite(efface, null);				
				addSprite(womenhairsSprite[hairValueWomen-1], null);
			}
			
			/*========================== d�tection des accessoires coch�s par l'user ====================
			 * 
			 */
			// joue rouge
			if(etat == 1){ addSprite(item_blush, null); }

			//lunettes
			if(etat1 == 1){ addSprite(item_glasses, null); }
			
			//ruban
			if(etat2 == 1){ addSprite(item_ruban, null); }
			
			//Update the new avatar
			layeredPane.updateUI();
		}
		
		/*=============================== method which changes the JSlider Panel value considering the type of sex chosen ===================*/
		public void checkGenre()
		{		
			if(sexeSelected == "men")
			{
				for(int i=0;i<menhairsSprite.length;i++)
				{
					sizeJSlider = i+1; // car on commence � 0
				}
				//System.out.println("sizeJSlider for men "+sizeJSlider);
				//selectImage();
				/*========= Updating of the JSlider in the control panel =========*/
				controlPanel.remove(hairSlider);
				hairsSlider();
				controlPanel.updateUI();
				/*========= Updating of the picture in the layeredPane =========*/
			}
			else if(sexeSelected == "women")
			{
				for(int i=0;i<womenhairsSprite.length;i++)
				{
					sizeJSlider = i+1; // car on commence � 0
				}
				//System.out.println("sizeJSlider for women "+sizeJSlider);
				//selectImage();
				/*========= Updating of the JSlider in the control panel =========*/
				controlPanel.remove(hairSlider);
				hairsSlider();
				controlPanel.updateUI();
				/*========= Updating of the picture in the layeredPane =========*/
			}
			
		}	
}
