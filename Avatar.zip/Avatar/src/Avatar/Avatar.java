package Avatar;


public class Avatar 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		// creating of a new interface
		new GUI();
		
	}
}
